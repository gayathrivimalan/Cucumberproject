package stepDefinitions;

import pageObjects.LoginPage;

public class BaseClass {
	public LoginPage loginPage;

}
